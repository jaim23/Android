/** Automatically generated file. DO NOT MODIFY */
package es.uca.flashandroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}